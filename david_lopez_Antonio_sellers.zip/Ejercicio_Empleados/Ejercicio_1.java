package Ejercicio_Empleados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class Ejercicio_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Connection con;
        PreparedStatement sentencia;
        String sql;

        String url = "jdbc:mysql://localhost:3307/empresa";
        
        try {
            con = DriverManager.getConnection(url, "DavidLopez", "Davidloopez08");
            sql = "SELECT * FROM empleados ";
            
            sentencia = con.prepareStatement(sql);
            
            ResultSet rs = sentencia.executeQuery();
            
            while(rs.next()) {
            	 String num = rs.getString("numemp");
            	 String nombre = rs.getString("nombre");
            	 int edad = rs.getInt("edad");
            	 int oficina = rs.getInt("oficina");
            	 String puesto = rs.getString("puesto");
            	 Date contrato = rs.getDate("contrato");
                
           	 System.out.println(num 
                		+ "\t" + nombre 
                		+ "\t" + edad 
                		+ "\t" + oficina 
                		+ "\t" + puesto
                		+ "\t" + contrato);
            }
            
            
            con.close(); //cerramos la conexión
        } catch (SQLException ex) {
            System.out.println("Ha ocurrido algún error." + ex.getMessage());
        }
    }
		
}



