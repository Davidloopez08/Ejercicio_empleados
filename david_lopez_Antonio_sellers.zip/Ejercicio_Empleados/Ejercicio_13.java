package Ejercicio_Empleados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Scanner;

public class Ejercicio_13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Connection con = null;
        PreparedStatement sentencia = null;

        String url = "jdbc:mysql://localhost:3307/empresa";
        
        try {
        	con = DriverManager.getConnection(url, "DavidLopez", "Davidloopez08");
        	
        	System.out.println("¿Que quieres cambiarle a la oficina la ciudad, las ventas o ambas? (1, 2 o 3):");
        	int opcion = new Scanner(System.in).nextInt();
			
        	if (opcion == 1) {
        		System.out.println("Dime el numero de la oficina a la cual quieras cambiarle de ciudad: ");
    			String oficina = new Scanner(System.in).nextLine();
    			System.out.println("Ahora dime el nombre de la ciudad la cual quieres ponerle: ");
    			String ciudad = new Scanner(System.in).nextLine();
    			
    			String sql = "UPDATE oficinas SET ciudad = ? WHERE oficina = ? ";
                
    			sentencia = con.prepareStatement(sql);
    			sentencia.setString(1, ciudad);
                sentencia.setString(2, oficina);
    			sentencia.executeUpdate();
			} else if(opcion == 2){
				System.out.println("Dime el numero de oficina a la que quieres cambiarle las ventas: ");
				int oficina = new Scanner(System.in).nextInt();
				System.out.println("Ahora dime de cuanto es la suma que quieres agregarle al importe de las ventas: ");
				int adicinal = new Scanner(System.in).nextInt();

				
				String sql2 = "UPDATE oficinas SET ventas = ventas + ? WHERE oficina = ? ";
				sentencia = con.prepareStatement(sql2);
	            sentencia.setInt(1, adicinal);
	            sentencia.setInt(2, oficina);
	            sentencia.executeUpdate();
			}else {
				
				System.out.println("Dime el numero de oficina que quieres cambiarle la ciudad y el importe de las ventas: ");
				int oficina = new Scanner(System.in).nextInt();
				
				System.out.println("Dime el nombre de la ciudad la cual quieres ponerle: ");
				String ciudad = new Scanner(System.in).next();
				
				System.out.println("Ahora dime cuanto quieres añadirle al importe de las ventas de esta oficina: ");
				int adicional = new Scanner(System.in).nextInt();
				
				String sql2 = "UPDATE oficinas SET ventas = ventas + ?, ciudad = ? WHERE oficina = ? ";
				sentencia = con.prepareStatement(sql2);
	            sentencia.setInt(1, adicional);
	            sentencia.setString(2, ciudad);
	            sentencia.setInt(3, oficina);
	            sentencia.executeUpdate();
				
			}
			
		} catch (Exception e) {
			
		}
		
	}

}
