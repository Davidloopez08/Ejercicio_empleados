package Ejercicio_Empleados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ejercicio_19 {

	 public static void main(String[] args) {
	        int oficinaOrigen = 1;  // La oficina de origen
	        int oficinaDestino = 5; // La nueva oficina

	        // Establecer la conexión con la base de datos
	        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/empresa", "DavidLopez", "Davidloopez08")) {

	        	// Mostrar empleados antes del cambio
	        	System.out.println("Empleados antes del cambio:");
	        	mostrarEmpleadosPorOficina(connection, oficinaDestino);  // Cambiar a oficinaDestino

	            // Realizar el cambio de oficina
	            cambiarOficina(connection, oficinaOrigen, oficinaDestino);

	            // Mostrar empleados después del cambio
	            System.out.println("\nEmpleados después del cambio:");
	            mostrarEmpleadosPorOficina(connection, oficinaDestino);

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private static void mostrarEmpleadosPorOficina(Connection connection, int oficina) throws SQLException {
	        String sql = "SELECT * FROM empleados WHERE oficina = ?";
	        try (PreparedStatement statement = connection.prepareStatement(sql)) {
	            statement.setInt(1, oficina);
	            ResultSet resultSet = statement.executeQuery();
	            while (resultSet.next()) {
	                System.out.println("Nombre: " + resultSet.getString("nombre") +
	                        ", Puesto: " + resultSet.getString("puesto"));
	            }
	        }
	    }

	    private static void cambiarOficina(Connection connection, int oficinaOrigen, int oficinaDestino) throws SQLException {
	        String sql = "UPDATE empleados SET oficina = ? WHERE oficina = ?";
	        try (PreparedStatement statement = connection.prepareStatement(sql)) {
	            statement.setInt(1, oficinaDestino);
	            statement.setInt(2, oficinaOrigen);
	            int rowsAffected = statement.executeUpdate();
	            System.out.println("\nSe han cambiado " + rowsAffected + " empleados de oficina.");
	        }
	    }

}
