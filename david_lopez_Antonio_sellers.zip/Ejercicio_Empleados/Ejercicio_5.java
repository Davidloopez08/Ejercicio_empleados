package Ejercicio_Empleados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.SQLException;
import java.sql.Date;

public class Ejercicio_5 {

    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement sentencia = null;

        String url = "jdbc:mysql://localhost:3307/empresa";

        try {
            con = DriverManager.getConnection(url, "DavidLopez", "Davidloopez08");

            System.out.println("Ingrese los datos del empleado que desea agregar :");
            System.out.println("Nombre :");
            String nombre = new Scanner(System.in).nextLine();
            System.out.println("Edad :");
            int edad = new Scanner(System.in).nextInt();
            System.out.println("Oficina :");
            int oficina = new Scanner(System.in).nextInt();
            System.out.println("Puesto :");
            String puesto = new Scanner(System.in).nextLine();
            
            Date fechaHoy = new Date(System.currentTimeMillis());

            String sql = "INSERT INTO empleados (nombre, edad, oficina, puesto, contrato) VALUES (?, ?, ?, ?, ?)";
            sentencia = con.prepareStatement(sql);
            sentencia.setString(1, nombre);
            sentencia.setInt(2, edad);
            sentencia.setInt(3, oficina);
            sentencia.setString(4, puesto);
            sentencia.setDate(5, fechaHoy);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
}
