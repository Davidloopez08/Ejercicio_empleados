package Ejercicio_Empleados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class EmpleadoDAO {
	
	private static final String URL = "jdbc:mysql://localhost:3307/empresa";
    private static final String USER = "antonio_sellers";
    private static final String PASSWORD = "Antoniosf2004.";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Obtener el número de empleado a borrar
        System.out.println("Ingrese el número de empleado a borrar:");
        int numEmpleado = scanner.nextInt();

        // Crear la instancia del DAO y borrar el empleado
        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        empleadoDAO.borrarEmpleado(numEmpleado);

        // Cerrar el escáner
        scanner.close();
    }

    public void borrarEmpleado(int numEmpleado) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establecer la conexión
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Crear la consulta SQL para borrar el empleado
            String sql = "DELETE FROM empleados WHERE numemp = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, numEmpleado);

            // Ejecutar la consulta
            int filasAfectadas = preparedStatement.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Empleado borrado correctamente.");
            } else {
                System.out.println("No se encontró ningún empleado con ese número.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar la conexión y la declaración
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
